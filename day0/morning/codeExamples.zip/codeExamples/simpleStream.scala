import org.apache.spark._
import org.apache.spark.streaming._
import org.apache.spark.streaming.StreamingContext._ // not necessary since Spark 1.3

sc.setLogLevel("ERROR")
val conf = sc.getConf

// stop the spark context and start the streaming context
sc.stop

// Create a local StreamingContext with two working thread and batch interval of 1 second.
// The master requires 2 cores to prevent from a starvation scenario.
val ssc = new StreamingContext(conf, Seconds(1))

// taken from docs https://spark.apache.org/docs/latest/streaming-programming-guide.html
val lines = ssc.socketTextStream("localhost", 9999)

// Split each line into words
val words = lines.flatMap(_.split(" "))

import org.apache.spark.streaming.StreamingContext._ // not necessary since Spark 1.3
// Count each word in each batch
val pairs = words.map(word => (word, 1))
val wordCounts = pairs.reduceByKey(_ + _)

// Print the first ten elements of each RDD generated in this DStream to the console
//print("test")
// print input as gathered in microbatch
words.print()
// print count
wordCounts.print()                                                                         



