import org.apache.sysml.api.mlcontext.MLContext
import org.apache.sysml.api.mlcontext._

// works in spark-shell only...
val ml = new MLContext(sc)

// getting data from url (commented out)
// val habermanUrl = "http://archive.ics.uci.edu/ml/machine-learning-databases/haberman/haberman.data"
// val habermanList = scala.io.Source.fromURL(habermanUrl).mkString.split("\n")

// loading local copy of data
val habermanList = scala.io.Source.
                   fromFile("haberman.data").
                   mkString.split("\n") 

val habermanRDD = sc.parallelize(habermanList)
val habermanMetadata = new MatrixMetadata(306, 4)
val typesRDD = sc.parallelize(Array("1.0,1.0,1.0,2.0"))
val typesMetadata = new MatrixMetadata(1, 4)

// getting dml script from url
// val scriptUrl = "https://raw.githubusercontent.com/apache/incubator-systemml/master/scripts/algorithms/Univar-Stats.dml"
// val uni = ScriptFactory.dmlFromUrl(scriptUrl).in("A", habermanRDD, habermanMetadata).in("K", typesRDD, typesMetadata).in("$CONSOLE_OUTPUT", true)

// loading local copy of dml
val sysmlHome = System.getenv("SYSTEMML_HOME")
val uni = ScriptFactory.
    dmlFromFile(sysmlHome + "/scripts/algorithms/Univar-Stats.dml").
    in("A", habermanRDD, habermanMetadata).
    in("K", typesRDD, typesMetadata).in("$CONSOLE_OUTPUT", true)


ml.execute(uni)  
 
