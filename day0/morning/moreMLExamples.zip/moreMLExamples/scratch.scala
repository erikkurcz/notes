graph.triplets.map(
  triplet => {  // Send Message
    if (triplet.srcAttr + triplet.attr < triplet.dstAttr) {
      (triplet.dstId, triplet.srcAttr + triplet.attr)
    } else {
      (0,0)b 
    }
  }
 )
