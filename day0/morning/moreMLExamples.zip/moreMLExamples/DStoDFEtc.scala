case class Person(name:String, age:Long)
val spark_home = System.getenv("SPARK_HOME")
val df = spark.read.json(spark_home + "/examples/src/main/resources/people.json")
val ds = df.as[Person]
ds.printSchema
