export SPARK_HOME=/Users/jeromenilmeier/Downloads/spark-2.0.2-bin-hadoop2.7

# using spark packages:
bash -x $SPARK_HOME/bin/spark-shell --packages graphframes:graphframes:0.2.0-spark2.0-s_2.11

#using local jar
#bash -x $SPARK_HOME/bin/spark-shell --jars graphframes-0.3.0-spark2.0-s_2.11.jar

