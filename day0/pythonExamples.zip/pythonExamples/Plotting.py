
# coding: utf-8

# In[2]:

import numpy as np
import matplotlib.pyplot as plt
#get_ipython().magic(u'matplotlib inline')


# # Plotting A Line

# In[20]:

# define a domain to plot
x = np.array(xrange(-5,6))
print(x)

# Define slope and intercept
m = 5
b = 3
y = m * x + b

#printing x and y
print("Domain (x):")
print (x)
print("Range (y): for y = "+ str(m)+"*x + "+str(b))
print(y)


# In[29]:

plt.plot(x,y,'-o')
plt.title("my first plot!")
plt.xlabel("x axis")
plt.ylabel("y axis")
plt.grid()
plt.show()

